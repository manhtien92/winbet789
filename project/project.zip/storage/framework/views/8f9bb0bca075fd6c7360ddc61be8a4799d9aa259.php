<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('sidebar'); ?>
    @parent

    <p>This is appended to the master sidebar.</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	
	<div ui-view></div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>