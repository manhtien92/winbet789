//Client socket


var userList = [];
var memberList 	= [];
var adminList = [];
var userCount 	= 0;
//Game site
var gamesiteList = [];

exports.userList 	= userList;
exports.memberList 	= memberList;
exports.adminList = adminList;
exports.userCount 	= userCount;
exports.gamesiteList 	= gamesiteList;