<div class="copyright text-center">
	<h3>WINBET789</h3>
</div>
<div id="dialog" title="Notice">
  	<p class="dialog-content">Register Success</p>
</div>