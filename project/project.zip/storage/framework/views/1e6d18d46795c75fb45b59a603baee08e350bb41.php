<meta charset="utf-8">
<meta name="description" content="">
<meta name="author" content="Huquduy">

<title>hokibet188</title>
<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(URL::asset('assets/admin/imgs/logo.png')); ?>" />
<!-- Import font -->
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/font/font-awesome-4.5.0/css/font-awesome.min.css')); ?>">


<!-- AngularJs area -->
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/js/node_modules/ng-dialog/css/ngDialog.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/js/node_modules/ng-dialog/css/ngDialog-theme-flat.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/js/node_modules/ng-dialog/css/ngDialog-theme-default.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/js/node_modules/ng-dialog/css/ngDialog-theme-plain.css')); ?>">

<!-- Import Css -->
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/third-party/bootstrap/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/third-party/jquery-ui-1.11.4/jquery-ui.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/css/client/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/css/client/customize.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/css/client/responsive.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/third-party/bxslider/jquery.bxslider.css')); ?>">




<script type="text/javascript">
	var baseUrl = "<?php echo e(URL::to('/')); ?>" + '/';
</script>